---
title: First principles investigation of small molecules adsorption on antimonene
authors:
- Rui-Shen Meng
- Miao Cai
- Jun-Ke Jiang
- Qiu-Hua Liang
- Xiang Sun
- Qun Yang
- Chun-Jian Tan
- Xian-Ping Chen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.723484Z'
publication_types:
- article-journal
publication: '*IEEE Electron Device Letters*'
---

---
title: Tuning the properties of multilayered perovskites and their interfaces for
  optoelectronic applications
authors:
- Jacky Even
- Boubacar Traore
- Claudio Quarti
- Junke Jiang
- Laurent Pedesseau
- Yorgos Volonakis
- Mikaël Kepenekian
- Claudine Katan
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.243023Z'
publication_types:
- paper-conference
publication: '*OPTIQUE Nice 2022*'
---

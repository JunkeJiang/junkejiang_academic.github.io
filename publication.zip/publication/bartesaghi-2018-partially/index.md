---
title: 'Partially replacing Pb2+ by Mn2+ in hybrid metal halide perovskites: Structural
  and electronic properties'
authors:
- Davide Bartesaghi
- Aniruddha Ray
- Junke Jiang
- Ricardo KM Bouwer
- Shuxia Tao
- Tom J Savenije
date: '2018-01-01'
publishDate: '2025-06-06T20:41:33.872463Z'
publication_types:
- article-journal
publication: '*APL Materials*'
---

---
title: Exploration of new ferromagnetic, semiconducting and biocompatible Nb 3 X 8
  (X= Cl, Br or I) monolayers with considerable visible and infrared light absorption
authors:
- Junke Jiang
- Qiuhua Liang
- Ruishen Meng
- Qun Yang
- Chunjian Tan
- Xiang Sun
- Xianping Chen
date: '2017-01-01'
publishDate: '2025-06-06T20:41:33.749259Z'
publication_types:
- article-journal
publication: '*Nanoscale*'
---

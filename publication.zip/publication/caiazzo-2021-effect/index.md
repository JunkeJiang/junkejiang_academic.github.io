---
title: Effect of Co-Solvents on the Crystallization and Phase Distribution of Mixed-Dimensional
  Perovskites (Adv. Energy Mater. 42/2021)
authors:
- Alessandro Caiazzo
- Kunal Datta
- Junke Jiang
- Marı́a C Gélvez-Rueda
- Junyu Li
- Riccardo Ollearo
- José Manuel Vicent-Luna
- Shuxia Tao
- Ferdinand C Grozema
- Martijn M Wienk
- ' others'
date: '2021-01-01'
publishDate: '2025-06-06T20:41:34.095013Z'
publication_types:
- article-journal
publication: '*Advanced Energy Materials*'
---

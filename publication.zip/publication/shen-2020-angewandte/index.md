---
title: Angewandte
authors:
- Qing Shen
- Feng Liu
- Junke Jiang
- Yaohong Zhang
- Chao Ding
- Taro Toyoda
- Shuzi Hayase
- Ruixiang Wang
- Shuxia Tao
date: '2020-01-01'
publishDate: '2025-06-06T20:41:34.658166Z'
publication_types:
- article-journal
---

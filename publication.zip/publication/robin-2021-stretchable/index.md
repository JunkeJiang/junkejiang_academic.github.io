---
title: Stretchable AgX (X= Se, Te) for Efficient Thermoelectrics and Photovoltaics
authors:
- Yee Hui Robin Chang
- Junke Jiang
- Heng Yen Khong
- Ismail Saad
- Soo See Chai
- Mohd Muzamir Mahat
- Shuxia Tao
date: '2021-01-01'
publishDate: '2025-06-06T20:41:34.021941Z'
publication_types:
- article-journal
publication: '*ACS Applied Materials & Interfaces*'
---

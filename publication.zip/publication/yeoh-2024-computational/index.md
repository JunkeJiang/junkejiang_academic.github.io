---
title: Computational Screening of a Single-Atom Catalyst Supported by Monolayer Nb2S2C
  for Oxygen Reduction Reaction
authors:
- KH Yeoh
- YHR Chang
- K-H Chew
- J Jiang
- Tiem Leong Yoon
- Duu Sheng Ong
- BT Goh
date: '2024-01-01'
publishDate: '2025-06-06T20:41:34.512902Z'
publication_types:
- article-journal
publication: '*Langmuir*'
---

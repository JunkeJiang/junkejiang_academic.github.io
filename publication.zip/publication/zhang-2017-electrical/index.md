---
title: Electrical and optical properties of NO and H 2 S adsorption on Arsenic Phosphorus
authors:
- Yingying Zhang
- Kai Zheng
- Xianping Chen
- Guoqi Zhang
- Chunjian Tan
- Qun Yang
- Junke Jiang
- Huaiyu Ye
- ' others'
date: '2017-01-01'
publishDate: '2025-06-06T20:41:33.784679Z'
publication_types:
- paper-conference
publication: '*2017 18th International Conference on Thermal, Mechanical and Multi-Physics
  Simulation and Experiments in Microelectronics and Microsystems (EuroSimE)*'
---

---
title: Influence of ion-exchange on lead-free inorganic Sn halide Perovskites
authors:
- J Jiang
- PA Bobbert
- SX Tao
date: '2018-01-01'
publishDate: '2025-06-06T20:41:33.845601Z'
publication_types:
- paper-conference
publication: '*Proceedings of International Conference on Perovskite Thin Film Photovoltaics,
  Photonics and Optoelectronics (ABXPV18PEROPTO) 2018*'
---

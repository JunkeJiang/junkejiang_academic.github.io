---
title: 'Graphane/fully hydrogenated h-BN bilayer: Marvellous dihydrogen bonding and
  effective band structure engineering'
authors:
- Junke Jiang
- Qiuhua Liang
- Xiang Sun
- Xianping Chen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.688466Z'
publication_types:
- paper-conference
publication: '*2016 17th International Conference on Electronic Packaging Technology
  (ICEPT)*'
---

---
title: Moisture-Insensitive, Phase-Stable Indium-Based Metal Halides and Their Light-Emitting
  Applications
authors:
- Zhe Tang
- Xuan Meng
- Hongyuan Zhao
- Sujun Ji
- Qiujie Wang
- Tianxin Bai
- Ruiling Zhang
- Junke Jiang
- Claudine Katan
- Jacky Even
- ' others'
date: '2023-01-01'
publishDate: '2025-06-06T20:41:34.284515Z'
publication_types:
- article-journal
publication: '*Advanced Optical Materials*'
---

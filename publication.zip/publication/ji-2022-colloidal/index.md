---
title: 'Colloidal synthesis of size-confined CsAgCl 2 nanocrystals: Implications for
  electroluminescence applications'
authors:
- Sujun Ji
- Xuan Meng
- Xiaochen Wang
- Tianxin Bai
- Ruiling Zhang
- Bin Yang
- Keli Han
- Junke Jiang
- Feng Liu
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.360141Z'
publication_types:
- article-journal
publication: '*Materials Chemistry Frontiers*'
---

---
title: Strain-Induced SiP--PtS2 Heterostructure with Fast Carrier Transport for Boosted
  Photocatalytic Hydrogen Conversion
authors:
- Yee Hui Robin Chang
- Kaiyuan Yao
- Keat Hoe Yeoh
- Masato Yoshiya
- Junke Jiang
- Moi Hua Tuh
- Heng Yen Khong
- Thong Leng Lim
date: '2023-01-01'
publishDate: '2025-06-06T20:41:34.488469Z'
publication_types:
- article-journal
publication: '*The Journal of Physical Chemistry C*'
---

---
title: Organic--Inorganic Hybrid Cuprous-Based Metal Halides for Warm White Light-Emitting
  Diodes
authors:
- Xuan Meng
- Sujun Ji
- Qiujie Wang
- Xiaochen Wang
- Tianxin Bai
- Ruiling Zhang
- Bin Yang
- Yimeng Li
- Zhipeng Shao
- Junke Jiang
- ' others'
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.462664Z'
publication_types:
- article-journal
publication: '*Advanced Science*'
---

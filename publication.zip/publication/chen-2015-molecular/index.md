---
title: Molecular Modeling of pH-Dependent Properties of Emeraldine Base Polyaniline
  for pH-Based Chemical Sensors
authors:
- Xianping Chen
- Cell KY Wong
- Tianling Ren
- Daoguo Yang
- Junke Jiang
- Qiuhua Liang
- Guoqi Zhang
date: '2015-01-01'
publishDate: '2025-06-06T20:41:33.401124Z'
publication_types:
- article-journal
publication: '*Molecular Modeling and Multiscaling Issues for Electronic Material
  Applications: Volume 2*'
---

---
title: Sorption and diffusion of water vapor and carbon dioxide in sulfonated polyaniline
  as chemical sensing materials
authors:
- Qiuhua Liang
- Junke Jiang
- Huaiyu Ye
- Ning Yang
- Miao Cai
- Jing Xiao
- Xianping Chen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.507810Z'
publication_types:
- article-journal
publication: '*Sensors*'
---

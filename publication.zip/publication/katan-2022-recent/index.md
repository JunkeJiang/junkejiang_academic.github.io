---
title: Recent results on metal halide perovskites and their interfaces
authors:
- Claudine Katan
- Boubacar Traore
- Claudio Quarti
- Junke Jiang
- Laurent Pedesseau
- Yorgos Volonakis
- Mikael Kepenekian
- Jacky Even
- ' others'
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.217251Z'
publication_types:
- paper-conference
publication: '*APS March Meeting Abstracts*'
---

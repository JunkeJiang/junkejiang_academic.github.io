---
title: 'From Dopant to Host: Solution Synthesis and Light-Emitting Applications of
  Organic-Inorganic Lanthanide-Based Metal Halides'
authors:
- Tianxin Bai
- Qiujie Wang
- Yunfei Bai
- Qichao Meng
- Hongyuan Zhao
- Ziying Wen
- Haibo Sun
- Li Huang
- Junke Jiang
- Dan Huang
- ' others'
date: '2024-01-01'
publishDate: '2025-06-06T20:41:34.574153Z'
publication_types:
- article-journal
publication: '*Small Structures*'
---

---
title: 'Scale-up Solutions of 2D Perovskite Photovoltaics: Insights of Multiscale
  Structures'
authors:
- Junke Jiang
- Jiaxue You
- Shengzhong Frank Liu
- Jun Xi
date: '2023-01-01'
publishDate: '2025-06-06T20:41:34.396114Z'
publication_types:
- article-journal
publication: '*ACS Energy Letters*'
---

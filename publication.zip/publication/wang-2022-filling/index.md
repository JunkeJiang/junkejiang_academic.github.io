---
title: 'Filling chlorine vacancy with bromine: A two-step hot-injection approach achieving
  defect-free hybrid halogen perovskite nanocrystals'
authors:
- Xiaochen Wang
- Tianxin Bai
- Xuan Meng
- Sujun Ji
- Ruiling Zhang
- Daoyuan Zheng
- Bin Yang
- Junke Jiang
- Ke-li Han
- Feng Liu
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.336409Z'
publication_types:
- article-journal
publication: '*ACS Applied Materials & Interfaces*'
---

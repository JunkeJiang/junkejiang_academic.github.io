---
title: First-principles study of gas adsorptin on indium nitride monolayer as gas
  sensor applications
authors:
- Xiang Sun
- Yiping Huang
- Junke Jiang
- Qiuhua Liang
- Ruishen Meng
- Chunjian Tan
- Qun Yang
- Xanping Chen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.699848Z'
publication_types:
- paper-conference
publication: '*2016 17th International Conference on Electronic Packaging Technology
  (ICEPT)*'
---

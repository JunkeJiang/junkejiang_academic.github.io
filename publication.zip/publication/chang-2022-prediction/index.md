---
title: Prediction of stable silver selenide-based energy materials sustained by rubidium
  selenide alloying
authors:
- Yee Hui Robin Chang
- Junke Jiang
- Keat Hoe Yeoh
- Moi Hua Tuh
- Fei Ha Chiew
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.347427Z'
publication_types:
- article-journal
publication: '*New Journal of Chemistry*'
---

---
title: Extending tight-binding models from bulk to layered halide perovskites
authors:
- Simon Thébaud
- Junke Jiang
- Baker Shalak
- Bruno Cucco
- Claudio Quarti
- George Volonakis
- Laurent Pedesseau
- Mikaël Kepenekian
- Claudine Katan
- Jacky Even
date: '2024-01-01'
publishDate: '2025-06-06T20:41:34.548569Z'
publication_types:
- paper-conference
publication: '*MATSUS Spring 2024 Conference*'
---

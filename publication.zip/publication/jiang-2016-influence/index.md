---
title: The Influence of Tensile Stress on Polyaniline as Strain Sensor
authors:
- Jun-Ke Jiang
- Qiu-Hua Liang
- Rui-Shen Meng
- Qun Yang
- Xiang Sun
- Dao-Guo Yang
- Guo-Qi Zhang
- Xian-Ping Chen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.653015Z'
publication_types:
- article-journal
publication: '*IEEE Electron Device Letters*'
---

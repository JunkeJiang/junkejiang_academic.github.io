---
title: Molecular modeling design of polyaniline as carbon dioxide sensor
authors:
- Qiuhua Liang
- Junke Jiang
- Xiang Sun
- Miao Cai
- Yiping Huang
- Daoguo Yang
- Xianping Chen
- Tianling Ren
date: '2015-01-01'
publishDate: '2025-06-06T20:41:33.459991Z'
publication_types:
- paper-conference
publication: '*2015 16th International Conference on Electronic Packaging Technology
  (ICEPT)*'
---

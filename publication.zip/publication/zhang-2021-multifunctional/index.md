---
title: Multifunctional molecule engineered SnO2 for perovskite solar cells with high
  efficiency and reduced lead leakage
authors:
- Jiali Zhang
- Renjie Li
- Sofia Apergi
- Pengyang Wang
- Biao Shi
- Junke Jiang
- Ningyu Ren
- Wei Han
- Qian Huang
- Geert Brocks
- ' others'
date: '2021-01-01'
publishDate: '2025-06-06T20:41:34.036027Z'
publication_types:
- article-journal
publication: '*Solar RRL*'
---

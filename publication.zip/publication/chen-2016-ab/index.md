---
title: Ab initio study of the adsorption of small molecules on stanene
authors:
- Xianping Chen
- Chunjian Tan
- Qun Yang
- Ruishen Meng
- Qiuhua Liang
- Miao Cai
- Shengli Zhang
- Junke Jiang
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.568334Z'
publication_types:
- article-journal
publication: '*The Journal of Physical Chemistry C*'
---

---
title: Recent results on metal halide perovskites and their interfaces
authors:
- Boubacar Traore
- Claudio Quarti
- Junke Jiang
- Laurent Pedesseau
- George Volonakis
- Mikael Kepenekian
- Jacky Even
- Claudine Katan
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.229926Z'
publication_types:
- paper-conference
publication: '*APS March Meeting 2022*'
---

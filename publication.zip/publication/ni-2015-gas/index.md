---
title: 'Gas adsorption on graphene with different layers: A first-principles study'
authors:
- Jiaming Ni
- Ning Yang
- Qiuhua Liang
- Junke Jiang
- Ruishen Meng
- Yiping Huang
- Xianping Chen
date: '2015-01-01'
publishDate: '2025-06-06T20:41:33.448402Z'
publication_types:
- paper-conference
publication: '*2015 16th International Conference on Electronic Packaging Technology
  (ICEPT)*'
---

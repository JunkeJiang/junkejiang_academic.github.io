---
title: On--Off Switching of Singlet Self-Trapped Exciton Emission Endows Antimony-Doped
  Indium Halides with Excitation-Wavelength-Dependent Luminescence
authors:
- Xinyu Yang
- Hongyuan Zhao
- Ziying Wen
- Yunfei Bai
- Qichao Meng
- Haibo Sun
- Xihong Ding
- Junke Jiang
- Dan Huang
- William W Yu
- ' others'
date: '2025-01-01'
publishDate: '2025-06-06T20:41:34.609466Z'
publication_types:
- article-journal
publication: '*Small*'
---

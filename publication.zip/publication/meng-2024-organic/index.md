---
title: Organic-Inorganic Hybrid Cuprous-Based Metal Halides with Unique Two-Dimensional
  Crystal Structure for White Light-Emitting Diodes
authors:
- Xuan Meng
- Junke Jiang
- Xinyu Yang
- Hongyuan Zhao
- Qichao Meng
- Yunfei Bai
- Qiujie Wang
- Jitao Song
- Claudine Katan
- Jacky Even
- ' others'
date: '2024-01-01'
publishDate: '2025-06-06T20:41:34.597649Z'
publication_types:
- article-journal
publication: '*Angewandte Chemie*'
---

---
title: First-principles study of sulfur dioxide sensor based on phosphorenes
authors:
- Qun Yang
- Rui-Shen Meng
- Jun-Ke Jiang
- Qiu-Hua Liang
- Chun-Jian Tan
- Miao Cai
- Xiang Sun
- Dao-Guo Yang
- Tian-Ling Ren
- Xian-Ping Chen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.495922Z'
publication_types:
- article-journal
publication: '*IEEE Electron Device Letters*'
---

---
title: Ultraviolet Emission from Cerium-Based Organic-Inorganic Hybrid Halides and
  Their Abnormal Anti-Thermal Quenching Behavior
authors:
- Qiujie Wang
- Tianxin Bai
- Sujun Ji
- Hongyuan Zhao
- Xuan Meng
- Ruiling Zhang
- Junke Jiang
- Feng Liu
date: '2023-01-01'
publishDate: '2025-06-06T20:41:34.425303Z'
publication_types:
- article-journal
publication: '*Advanced Functional Materials*'
---

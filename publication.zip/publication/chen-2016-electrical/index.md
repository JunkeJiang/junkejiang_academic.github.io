---
title: Electrical and optical properties of germanene on single-layer BeO substrate
authors:
- Xianping Chen
- Xiang Sun
- Junke Jiang
- Qiuhua Liang
- Qun Yang
- Ruishen Meng
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.628799Z'
publication_types:
- article-journal
publication: '*The Journal of Physical Chemistry C*'
---

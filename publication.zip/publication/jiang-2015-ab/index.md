---
title: Ab initio studies of the differences in the chemical reactivity and electronic
  properties of polyaniline and its derivatives
authors:
- Junke Jiang
- Qiuhua Liang
- Chunjian Tan
- Miao Cai
- Yiping Huang
- Daoguo Yang
- Xianping Chen
- Tianling Ren
date: '2015-01-01'
publishDate: '2025-06-06T20:41:33.434564Z'
publication_types:
- paper-conference
publication: '*2015 16th International Conference on Electronic Packaging Technology
  (ICEPT)*'
---

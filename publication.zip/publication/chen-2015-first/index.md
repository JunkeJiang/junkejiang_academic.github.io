---
title: First-principles study of the effect of functional groups on polyaniline backbone
authors:
- XP Chen
- JK Jiang
- QH Liang
- N Yang
- HY Ye
- M Cai
- L Shen
- DG Yang
- TL Ren
date: '2015-01-01'
publishDate: '2025-06-06T20:41:33.471236Z'
publication_types:
- article-journal
publication: '*Scientific reports*'
---

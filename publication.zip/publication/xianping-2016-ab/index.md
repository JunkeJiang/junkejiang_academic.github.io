---
title: Ab Initio Study of the Adsorption of Small Molecules on Stanene
authors:
- Chen Xianping
- Tan Chunjian
- Yang Qun
- Meng Ruishen
- Liang Qiuhua
- Cai Miao
- Zhang Shengli
- Jiang Junke
date: '2016-01-01'
publishDate: '2025-06-06T20:41:34.323434Z'
publication_types:
- article-journal
---

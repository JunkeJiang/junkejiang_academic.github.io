---
title: Structural Isomer of Fluorinated Ruddlesden-Popper Perovskites Toward Efficient
  and Stable 2D/3D Perovskite Solar Cells
authors:
- Junseop Byeon
- Seong Ho Cho
- Junke Jiang
- Jihun Jang
- Claudine Katan
- Jacky Even
- Jun Xi
- Mansoo Choi
- Yun Seog Lee
date: '2023-01-01'
publishDate: '2025-06-06T20:41:34.204060Z'
publication_types:
- article-journal
publication: '*ACS Applied Materials & Interfaces*'
---

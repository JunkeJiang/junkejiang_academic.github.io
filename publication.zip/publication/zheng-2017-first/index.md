---
title: First principle design of CdS/germanene heterostructures with tunable electronic
  and transport properties
authors:
- Kai Zheng
- Huaiyu Ye
- Guoqi Zhang
- Yingying Zhang
- Lian Liu
- Junke Jiang
- Qun Yang
- Chunjian Tan
- Xianping Chen
date: '2017-01-01'
publishDate: '2025-06-06T20:41:33.797455Z'
publication_types:
- paper-conference
publication: '*2017 18th International Conference on Thermal, Mechanical and Multi-Physics
  Simulation and Experiments in Microelectronics and Microsystems (EuroSimE)*'
---

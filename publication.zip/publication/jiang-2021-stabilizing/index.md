---
title: Stabilizing metal halide perovskites by computational compositional engineering
authors:
- Junke Jiang
date: '2021-01-01'
publishDate: '2025-06-06T20:41:34.047626Z'
publication_types:
- article-journal
---

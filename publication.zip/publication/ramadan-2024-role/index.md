---
title: The Role of the Organic Cation in Developing Efficient Green Perovskite LEDs
  Based on Quasi-2D Perovskite Heterostructures
authors:
- Alexandra J Ramadan
- Woo Hyeon Jeong
- Robert DJ Oliver
- Junke Jiang
- Akash Dasgupta
- Zhongcheng Yuan
- Joel Smith
- Jae Eun Lee
- Silvia G Motti
- Olivia Gough
- ' others'
date: '2024-01-01'
publishDate: '2025-06-06T20:41:34.407891Z'
publication_types:
- article-journal
publication: '*Advanced Functional Materials*'
---

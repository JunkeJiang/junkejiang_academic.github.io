---
title: Effect of multilayer structure, stacking order and external electric field
  on the electrical properties of few-layer boron-phosphide
authors:
- Xianping Chen
- Chunjian Tan
- Qun Yang
- Ruishen Meng
- Qiuhua Liang
- Junke Jiang
- Xiang Sun
- DQ Yang
- Tianling Ren
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.532099Z'
publication_types:
- article-journal
publication: '*Physical Chemistry Chemical Physics*'
---

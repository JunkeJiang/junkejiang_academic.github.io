---
title: Tunable electronic structure and enhanced optical properties in quasi-metallic
  hydrogenated/fluorinated SiC heterobilayer
authors:
- Xianping Chen
- Junke Jiang
- Qiuhua Liang
- Ruishen Meng
- Chunjian Tan
- Qun Yang
- Shengli Zhang
- Haibo Zeng
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.593194Z'
publication_types:
- article-journal
publication: '*Journal of Materials Chemistry C*'
---

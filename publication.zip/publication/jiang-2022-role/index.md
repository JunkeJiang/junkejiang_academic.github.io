---
title: "The role of solvents in the formation of methylammonium lead triiodide perovskite"
authors:
- Junke Jiang
- José Manuel Vicent-Luna
- Shuxia Tao
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.071786Z'
publication_types: ["article-journal"]
publication: "*Journal of Energy Chemistry*"
doi: 10.1016/j.jechem.2021.12.030
featured: true
---

---
title: 'SiGe/h-BN heterostructure with inspired electronic and optical properties:
  a first-principles study'
authors:
- Xianping Chen
- Xiang Sun
- DG Yang
- Ruishen Meng
- Chunjian Tan
- Qun Yang
- Qiuhua Liang
- Junke Jiang
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.663937Z'
publication_types:
- article-journal
publication: '*Journal of Materials Chemistry C*'
---

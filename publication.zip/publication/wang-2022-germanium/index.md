---
title: 'Germanium Halides Serving as Ideal Precursors: Designing a More Effective
  and Less Toxic Route to High-Optoelectronic-Quality Metal Halide Perovskite Nanocrystals'
authors:
- Xiaochen Wang
- Tianxin Bai
- Bin Yang
- Ruiling Zhang
- Daoyuan Zheng
- Junke Jiang
- Shuxia Tao
- Feng Liu
- Ke-li Han
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.110862Z'
publication_types:
- article-journal
publication: '*Nano Letters*'
---

---
title: Unlocking the porous, anomalous narrow band gap inorganic graphenylene-like
  CuO monolayer with post oxidation advantage for thermophotovoltaic and solar cell
authors:
- Yee Hui Robin Chang
- Keat Hoe Yeoh
- Junke Jiang
- Ishak Annuar
- Moi Hua Tuh
- Siow Hoo Leong
- Thong Leng Lim
- Lay Chen Low
- Yik Seng Yong
date: '2025-01-01'
publishDate: '2025-06-06T20:41:34.621697Z'
publication_types:
- article-journal
publication: '*Surfaces and Interfaces*'
---

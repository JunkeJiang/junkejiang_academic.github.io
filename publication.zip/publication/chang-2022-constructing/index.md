---
title: Constructing trifunctional MoTe 2/As van der Waals heterostructures for versatile
  energy applications
authors:
- Yee Hui Robin Chang
- Keat Hoe Yeoh
- Junke Jiang
- Thong Leng Lim
- Yik Seng Yong
- Lay Chen Low
- Moi Hua Tuh
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.372749Z'
publication_types:
- article-journal
publication: '*New Journal of Chemistry*'
---

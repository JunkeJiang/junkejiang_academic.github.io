---
title: 'Adsorption of gas molecules on graphene-like InN monolayer: A first-principle
  study'
authors:
- Xiang Sun
- Qun Yang
- Ruishen Meng
- Chunjian Tan
- Qiuhua Liang
- Junke Jiang
- Huaiyu Ye
- Xianping Chen
date: '2017-01-01'
publishDate: '2025-06-06T20:41:33.771921Z'
publication_types:
- article-journal
publication: '*Applied Surface Science*'
---

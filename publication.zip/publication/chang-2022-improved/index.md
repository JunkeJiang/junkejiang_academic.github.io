---
title: Improved Thermoelectric--Photovoltaic Performance of Ag2Se Originating from
  a Halogenation-Induced Wider Band Gap and Low Crystal Symmetry
authors:
- Yee Hui Robin Chang
- Junke Jiang
- Keat Hoe Yeoh
- Heng Yen Khong
- Mohd Muzamir Mahat
- Soo See Chai
- Ismail Saad
- Moi Hua Tuh
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.153789Z'
publication_types:
- article-journal
publication: '*ACS Applied Energy Materials*'
---

---
title: 'The electronic and optical properties of silicene/g-ZnS heterobilayers: a
  theoretical study'
authors:
- Xianping Chen
- Junke Jiang
- Qiuhua Liang
- Ruishen Meng
- Chunjian Tan
- Qun Yang
- Xiang Sun
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.581090Z'
publication_types:
- article-journal
publication: '*Journal of Materials Chemistry C*'
---

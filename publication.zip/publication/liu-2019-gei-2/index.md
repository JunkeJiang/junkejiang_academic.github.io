---
title: GeI2 Additive for High Optoelectronic Quality CsPbI3 Quantum Dots and Their
  Application in Photovoltaic Devices
authors:
- Feng Liu
- Chao Ding
- Yaohong Zhang
- Taichi Kamisaka
- Qian Zhao
- Joseph M Luther
- Taro Toyoda
- Shuzi Hayase
- Takashi Minemoto
- Kenji Yoshino
- ' others'
date: '2019-01-01'
publishDate: '2025-06-06T20:41:33.889175Z'
publication_types:
- article-journal
publication: '*Chemistry of Materials*'
---

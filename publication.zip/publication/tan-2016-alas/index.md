---
title: An AlAs/germanene heterostructure with tunable electronic and optical properties
  via external electric field and strain
authors:
- Chunjian Tan
- Qun Yang
- Ruishen Meng
- Qiuhua Liang
- Junke Jiang
- Xiang Sun
- Huaiyu Ye
- Xianping Chen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.605420Z'
publication_types:
- article-journal
publication: '*Journal of Materials Chemistry C*'
---

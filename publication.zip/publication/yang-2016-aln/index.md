---
title: AlN/BP heterostructure photocatalyst for water splitting
authors:
- Qun Yang
- Chun-Jian Tan
- Rui-Shen Meng
- Jun-Ke Jiang
- Qiu-Hua Liang
- Xiang Sun
- Dao-Guo Yang
- Xian-Ping Chen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.737199Z'
publication_types:
- article-journal
publication: '*IEEE Electron Device Letters*'
---

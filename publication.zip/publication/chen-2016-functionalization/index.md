---
title: 'Functionalization-induced changes in the structural and physical properties
  of amorphous polyaniline: a first-principles and molecular dynamics study'
authors:
- XP Chen
- QH Liang
- JK Jiang
- Cell KY Wong
- Stanley YY Leung
- HY Ye
- DG Yang
- TL Ren
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.484187Z'
publication_types:
- article-journal
publication: '*Scientific reports*'
---

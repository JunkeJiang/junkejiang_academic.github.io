---
title: Microscopic Degradation in Formamidinium-Cesium Lead Iodide Perovskite Solar
  Cells under Operational Stressors
authors:
- Nengxu Li
- Yanqi Luo
- Zehua Chen
- Xiuxiu Niu
- Xiao Zhang
- Jiuzhou Lu
- Rishi Kumar
- Junke Jiang
- Huifen Liu
- Xiao Guo
- ' others'
date: '2020-01-01'
publishDate: '2025-06-06T20:41:33.951424Z'
publication_types:
- article-journal
publication: '*Joule*'
---

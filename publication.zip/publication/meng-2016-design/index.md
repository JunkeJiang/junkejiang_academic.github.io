---
title: Design of graphene-like gallium nitride and WS 2/WSe 2 nanocomposites for photocatalyst
  applications
authors:
- Ruishen Meng
- Junke Jiang
- Qiuhua Liang
- Qun Yang
- Chunjian Tan
- Xiang Sun
- Xianping Chen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.641252Z'
publication_types:
- article-journal
publication: '*Science China Materials*'
---

---
title: Electronic coupling between perovskite nanocrystal and fullerene modulates
  hot carrier capture
authors:
- Yusheng Li
- Junke Jiang
- Dandan Wang
- Dong Liu
- Shota Yajima
- Hua Li
- Akihito Fuchimoto
- Hongshi Li
- Guozheng Shi
- Shuzi Hayase
- ' others'
date: '2024-01-01'
publishDate: '2025-06-06T20:41:34.179831Z'
publication_types:
- article-journal
publication: '*Advanced Functional Materials*'
---

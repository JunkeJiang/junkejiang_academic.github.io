---
title: Achieving type-II SnSSe/as van der waals heterostructure with satisfactory
  oxygen tolerance for optoelectronic and photovoltaic applications
authors:
- Yee Hui Robin Chang
- Junke Jiang
- Keat Hoe Yeoh
- Yusuf Zuntu Abdullahi
- Heng Yen Khong
- Moi Hua Tuh
- Fui Kiew Liew
- Yit Lian Liew
date: '2023-01-01'
publishDate: '2025-06-06T20:41:34.437835Z'
publication_types:
- article-journal
publication: '*Journal of Solid State Chemistry*'
---

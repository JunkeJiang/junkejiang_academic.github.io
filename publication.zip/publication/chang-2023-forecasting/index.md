---
title: 'Forecasting the unrevealed surface-controlled photocatalytic water splitting
  in two-dimensional Ag 2 Se with ultrafast carrier mobility: a first-principles study'
authors:
- Yee Hui Robin Chang
- Keat Hoe Yeoh
- Junke Jiang
- Soo See Chai
- Yusuf Zuntu Abdullahi
- Heng Yen Khong
- Thong Leng Lim
- Moi Hua Tuh
date: '2023-01-01'
publishDate: '2025-06-06T20:41:34.476879Z'
publication_types:
- article-journal
publication: '*Catalysis Science & Technology*'
---

---
title: Efficient Extraction of Hot Carriers in Perovskite Quantum Dot through Building
  State Coupled Complex
authors:
- Yusheng Li
- Junke Jiang
- Dandan Wang
- Dong Liu
- Shota Yajima
- Hua Li
- Akihito Fuchimoto
- Hongshi Li
- Guozheng Shi
- Shuzi Hayase
- ' others'
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.167733Z'
publication_types:
- article-journal
publication: '*arXiv preprint arXiv:2209.02202*'
---

---
title: Ab InitioStudy of Temperature, Humidity, and Covalent Functionalization-Induced
  Bandgap Change of Single-Walled Carbon Nanotubes
authors:
- Xian-Ping Chen
- Ning Yang
- Jun-Ke Jiang
- Qiu-Hua Liang
- Dao-Guo Yang
- Guo-Qi Zhang
- Tian-Ling Ren
date: '2015-01-01'
publishDate: '2025-06-06T20:41:33.419773Z'
publication_types:
- article-journal
publication: '*IEEE Electron Device Letters*'
---

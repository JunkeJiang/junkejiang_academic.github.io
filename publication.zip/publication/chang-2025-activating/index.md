---
title: Activating the Screened Thermoelectric and Photocatalytic Water-Splitting Potential
  in Janus Sn2XY (X$ne$ Y= Te, Se, and S) Monolayers via Doping and Strain Engineering
authors:
- Yee Hui Robin Chang
- Keat Hoe Yeoh
- Junke Jiang
- Soo See Chai
- Qiuhua Liang
- Moi Hua Tuh
- Siow Hoo Leong
- Thong Leng Lim
- Lay Chen Low
- Yik Seng Yong
date: '2025-01-01'
publishDate: '2025-06-06T20:41:34.646641Z'
publication_types:
- article-journal
publication: '*The Journal of Physical Chemistry C*'
---

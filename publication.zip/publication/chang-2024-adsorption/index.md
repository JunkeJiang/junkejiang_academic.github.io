---
title: Adsorption and reversible detection of toxic halogens gases at room temperature
  by two-dimensional Al2SSe for occupational sustainability
authors:
- Yee Hui Robin Chang
- Keat Hoe Yeoh
- Junke Jiang
- Hung Wei Yu
- Edward Yi Chang
- Chang Fu Dee
- Moi Hua Tuh
date: '2024-01-01'
publishDate: '2025-06-06T20:41:34.536214Z'
publication_types:
- article-journal
publication: '*Materials Today Communications*'
---

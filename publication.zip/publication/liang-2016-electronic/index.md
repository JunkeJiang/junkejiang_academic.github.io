---
title: Electronic properties and work functions of silicane/fully hydrogenated h-BN
  and silicane/graphane nanosheets
authors:
- Qiuhua Liang
- Junke Jiang
- Xiang Sun
- Xianping Chen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.675901Z'
publication_types:
- paper-conference
publication: '*2016 17th International Conference on Electronic Packaging Technology
  (ICEPT)*'
---

---
title: Electrical and Optical Properties of Germanene on Single-Layer BeO Substrate
authors:
- Chen Xianping
- Sun Xiang
- Jiang Junke
- Liang Qiuhua
- Yang Qun
- Meng Ruishen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:34.310058Z'
publication_types:
- article-journal
---

---
title: Steering device-quality perovskites with unique substrate tolerance
authors:
- Ningyu Ren
- Pengyang Wang
- Junke Jiang
- Renjie Li
- Wei Han
- Jingjing Liu
- Zhao Zhu
- Bingbing Chen
- Qiaojing Xu
- Tiantian Li
- ' others'
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.138753Z'
publication_types:
- article-journal
---

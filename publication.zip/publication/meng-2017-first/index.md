---
title: First principles investigation of small molecules adsorption on antimonene
  (EI 收录)
authors:
- Rui-Shen Meng
- Miao Cai
- Jun-Ke Jiang
- Qiu-Hua Liang
- Xiang Sun
- Qun Yang
- Chun-Jian Tan
- Xian-Ping Chen
- ' others'
date: '2017-01-01'
publishDate: '2025-06-06T20:41:34.083844Z'
publication_types:
- article-journal
---

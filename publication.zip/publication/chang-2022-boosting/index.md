---
title: Boosting the solar conversion efficiency of MoSe2/PtX2 (X= O, S) vdW heterostructure
  by strain and electric field engineering
authors:
- Yee Hui Robin Chang
- Keat Hoe Yeoh
- Junke Jiang
- Heng Yen Khong
- Mohd Muzamir Mahat
- Soo See Chai
- Fui Kiew Liew
- Moi Hua Tuh
date: '2022-01-01'
publishDate: '2025-06-06T20:41:34.450247Z'
publication_types:
- article-journal
publication: '*Physica Scripta*'
---

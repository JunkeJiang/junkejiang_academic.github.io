---
title: On the mechanism of solvents catalyzed structural transformation in metal halide
  perovskites
authors:
- Jun Xi
- Junke Jiang
- Herman Duim
- Lijun Chen
- Jiaxue You
- Giuseppe Portale
- Shengzhong Liu
- Shuxia Tao
- Maria Antonietta Loi
date: '2023-01-01'
publishDate: '2025-06-06T20:41:34.259161Z'
publication_types: ["article-journal"]
publication: '*Advanced Materials*'
doi: 10.1002/adma.202302896
featured: true
---

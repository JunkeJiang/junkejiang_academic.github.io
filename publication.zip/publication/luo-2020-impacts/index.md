---
title: The Impacts and Origins of A-site Instability in Formamidinium-Cesium Lead
  Iodide Perovskite Solar Cells Under Extended Operation
authors:
- Yanqi Luo
- Nengxu Li
- Zehua Chen
- Xiuxiu Niu
- Rishi E Kumar
- Junke Jiang
- Huifen Liu
- Oi Chen
- Barry Lai
- Geert Brocks
- ' others'
date: '2020-01-01'
publishDate: '2025-06-06T20:41:33.975703Z'
publication_types:
- paper-conference
publication: '*2020 47th IEEE Photovoltaic Specialists Conference (PVSC)*'
---

---
title: The intriguing electronic and optical properties modulation of hydrogen and
  fluorine codecorated silicene layers
authors:
- Qun Yang
- Chunjian Tan
- Ruishen Meng
- Junke Jiang
- Qiuhua Liang
- Xiang Sun
- Daoguo Yang
- Xianping Chen
date: '2017-01-01'
publishDate: '2025-06-06T20:41:33.711421Z'
publication_types:
- article-journal
publication: '*Applied surface science*'
---

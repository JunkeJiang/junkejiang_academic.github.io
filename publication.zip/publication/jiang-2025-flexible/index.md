---
title: "Flexible and efficient semiempirical DFTB parameters for electronic structure prediction of 3D, 2D iodide perovskites and heterostructures"
authors:
  - Junke Jiang
  - Tammo van der Heide
  - Simon Thébaud
  - Carlos Raúl Lien-Medrano
  - Arnaud Fihey
  - Laurent Pedesseau
  - Claudio Quarti
  - Marios Zacharias
  - George Volonakis
  - Mikael Kepenekian
  - others
date: 2025-01-01
publishDate: 2025-06-06T20:41:34Z
publication_types: ["article-journal"]
publication: "*Physical Review Materials*"
doi: 10.1103/PhysRevMaterials.9.023803
featured: true
---

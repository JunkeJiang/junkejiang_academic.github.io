---
title: Multifunctional Additive CdAc2 for Efficient Perovskite-Based Solar Cells
authors:
- Ningyu Ren
- Pengyang Wang
- Junke Jiang
- Renjie Li
- Wei Han
- Jingjing Liu
- Zhao Zhu
- Bingbing Chen
- Qiaojing Xu
- Tiantian Li
- ' others'
date: '2023-01-01'
publishDate: '2025-06-06T20:41:34.191397Z'
publication_types:
- article-journal
publication: '*Advanced Materials*'
---

---
title: Adsorption of gas molecules on graphene-like InN
authors:
- Xiang Sun
- Qun Yang
- Ruishen Meng
- Chunjian Tan
date: '1999-01-01'
publishDate: '2025-06-06T20:41:34.385033Z'
publication_types:
- article-journal
publication: '*Journal of Applied Physics*'
---

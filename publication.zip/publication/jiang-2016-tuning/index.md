---
title: Tuning the electronic and optical properties of graphane/silicane and fhBN/silicane
  nanosheets via interfacial dihydrogen bonding and electrical field control
authors:
- Junke Jiang
- Qiuhua Liang
- Shengli Zhang
- Ruishen Meng
- Chunjian Tan
- Qun Yang
- Xiang Sun
- Huaiyu Ye
- Xianping Chen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.616949Z'
publication_types:
- article-journal
publication: '*Journal of Materials Chemistry C*'
---

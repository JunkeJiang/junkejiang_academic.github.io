---
title: Stabilizing lead-free all-inorganic tin halide Perovskites by ion exchange
authors:
- Junke Jiang
- Chidozie K Onwudinanti
- Ross A Hatton
- Peter A Bobbert
- Shuxia Tao
date: '2018-01-01'
publishDate: '2025-06-06T20:41:33.861800Z'
publication_types:
- article-journal
publication: '*The Journal of Physical Chemistry C*'
---

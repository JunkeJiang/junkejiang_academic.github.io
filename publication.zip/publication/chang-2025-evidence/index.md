---
title: Evidence of the As/PtSe2 Heterostructure with a Robust Built-In Electric Field
  as a Competitive Z-Scheme Photocatalyst for Overall Water Splitting
authors:
- Yee Hui Robin Chang
- Masato Yoshiya
- Keat Hoe Yeoh
- Wan Izhan Nawawi Wan Ismail
- Junke Jiang
- Chanhyeok Kim
- Kaiyuan Yao
- Moi Hua Tuh
date: '2025-01-01'
publishDate: '2025-06-06T20:41:34.670904Z'
publication_types:
- article-journal
publication: '*The Journal of Physical Chemistry C*'
---

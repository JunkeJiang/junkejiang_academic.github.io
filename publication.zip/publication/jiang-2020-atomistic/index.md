---
title: Atomistic and Electronic Origin of Phase Instability of Metal Halide Perovskites
authors:
- Junke Jiang
- Feng Liu
- Ionut Tranca
- Qing Shen
- Shuxia Tao
date: '2020-01-01'
publishDate: '2025-06-06T20:41:33.937893Z'
publication_types: ["article-journal"]
publication: "*ACS Applied Energy Materials*"
doi: 10.1021/acsaem.0c00791
featured: true
---

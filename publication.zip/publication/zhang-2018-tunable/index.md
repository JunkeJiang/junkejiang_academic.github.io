---
title: 'Tunable electronic properties of silicene/GaP heterobilayer: Effects of electric
  field or biaxial tensile strain'
authors:
- Peng Zhang
- Xibin Yang
- Wei Wu
- Lifen Tian
- Heping Cui
- Kai Zheng
- Junke Jiang
- Xianping Chen
- Huaiyu Ye
date: '2018-01-01'
publishDate: '2025-06-06T20:41:33.826087Z'
publication_types:
- article-journal
publication: '*Chemical Physics Letters*'
---

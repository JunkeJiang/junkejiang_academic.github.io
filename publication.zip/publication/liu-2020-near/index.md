---
title: Near-Infrared Emission from Tin--Lead (Sn--Pb) Alloyed Perovskite Quantum Dots
  by Sodium Doping
authors:
- Feng Liu
- Junke Jiang
- Yaohong Zhang
- Chao Ding
- Taro Toyoda
- Shuzi Hayase
- Ruixiang Wang
- Shuxia Tao
- Qing Shen
date: '2020-01-01'
publishDate: '2025-06-06T20:41:33.926321Z'
publication_types:
- article-journal
publication: '*Angewandte Chemie*'
---

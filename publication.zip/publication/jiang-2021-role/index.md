---
title: "The role of sodium in stabilizing tin--lead (Sn--Pb) alloyed perovskite quantum dots"
authors:
- Junke Jiang
- Feng Liu
- Qing Shen
- Shuxia Tao
date: '2021-01-01'
publishDate: '2025-06-06T20:41:33.988966Z'
publication_types: ["article-journal"]
publication: "*Journal of Materials Chemistry A*"
doi: 10.1039/D1TA00955A
featured: true
---

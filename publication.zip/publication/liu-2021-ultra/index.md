---
title: 'Ultra-Halide-Rich Synthesis of Stable Pure Tin-Based Halide Perovskite Quantum
  Dots: Implications for Photovoltaics'
authors:
- Feng Liu
- Junke Jiang
- Taro Toyoda
- Muhammad Akmal Kamarudin
- Shuzi Hayase
- Ruixiang Wang
- Shuxia Tao
- Qing Shen
date: '2021-01-01'
publishDate: '2025-06-06T20:41:34.004077Z'
publication_types:
- article-journal
publication: '*ACS Applied Nano Materials*'
---

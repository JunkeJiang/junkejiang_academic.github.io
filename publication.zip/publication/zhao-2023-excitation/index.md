---
title: Excitation Wavelength-Dependent Fluorescence of a Lanthanide Organic Metal
  Halide Cluster for Anti-Counterfeiting Applications
authors:
- Hongyuan Zhao
- Qiujie Wang
- Ziying Wen
- Haibo Sun
- Sujun Ji
- Xuan Meng
- Ruiling Zhang
- Junke Jiang
- Zhe Tang
- Feng Liu
date: '2023-01-01'
publishDate: '2025-06-06T20:41:34.500374Z'
publication_types:
- article-journal
publication: '*Angewandte Chemie International Edition*'
---

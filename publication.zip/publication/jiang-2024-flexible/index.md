---
title: Flexible and Efficient Semi-Empirical DFTB methods for Electronic Structure
  Prediction of 3D, 2D Perovskites and Heterostructures
authors:
- Junke Jiang
- Tammo van der Heide
- Simon Thébaud
- Carlos R Lien-Medrano
- Marios Zacharias
- Arnaud Fihey
- George Volonakis
- Bálint Aradi
- Claudine Katan
- Thomas Frauenheim
- ' others'
date: '2024-01-01'
publishDate: '2025-06-06T20:41:34.560276Z'
publication_types:
- paper-conference
publication: '*MATSUS Spring 2024 Conference*'
---

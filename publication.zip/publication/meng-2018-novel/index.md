---
title: 'Novel GaN-based nanocomposites: Effective band structure and optical property
  tuning by tensile strain or external field'
authors:
- Ruishen Meng
- Xiang Sun
- Junke Jiang
- Qiuhua Liang
- Qun Yang
- Xianping Chen
date: '2018-01-01'
publishDate: '2025-06-06T20:41:33.810326Z'
publication_types:
- article-journal
publication: '*Applied Surface Science*'
---

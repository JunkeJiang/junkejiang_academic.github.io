---
title: Highly Luminescent Phase-Stable Hybrid Manganese Halides for Efficient X-ray
  Imaging
authors:
- Sujun Ji
- Yihang Liu
- Yulong Wang
- Hongyuan Zhao
- Qiujie Wang
- Qichao Meng
- Yunfei Bai
- Junke Jiang
- Qing Shen
- Feng Liu
date: '2024-01-01'
publishDate: '2025-06-06T20:41:34.525193Z'
publication_types:
- article-journal
publication: '*Crystal Growth & Design*'
---

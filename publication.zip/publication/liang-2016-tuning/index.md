---
title: Tuning the electronic properties and work functions of graphane/fully hydrogenated
  h-BN heterobilayers via heteronuclear dihydrogen bonding and electric field control
authors:
- Qiuhua Liang
- Junke Jiang
- Ruishen Meng
- Huaiyu Ye
- Chunjian Tan
- Qun Yang
- Xiang Sun
- Daoguo Yang
- Xianping Chen
date: '2016-01-01'
publishDate: '2025-06-06T20:41:33.544822Z'
publication_types:
- article-journal
publication: '*Physical Chemistry Chemical Physics*'
---

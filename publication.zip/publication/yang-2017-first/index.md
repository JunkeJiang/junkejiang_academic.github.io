---
title: First-principles approach to design and evaluation of graphene as methane sensors
authors:
- Daoguo Yang
- Ning Yang
- Jiaming Ni
- Jing Xiao
- Junke Jiang
- Qiuhua Liang
- Tianling Ren
- Xianping Chen
date: '2017-01-01'
publishDate: '2025-06-06T20:41:33.760020Z'
publication_types:
- article-journal
publication: '*Materials & Design*'
---

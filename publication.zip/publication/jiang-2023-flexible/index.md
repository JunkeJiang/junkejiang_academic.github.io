---
title: Flexible and Efficient Semi-Empirical DFTB methods for Electronic Structure
  Prediction of 3D, 2D and 3D/2D Halide Perovskites
authors:
- Junke Jiang
- Tammo van der Heide
- Simon Thébaud
- Carlos R Lien-Medrano
- Bálint Aradi
- Claudine Katan
- Thomas Frauenheim
- Jacky Even
date: '2023-01-01'
publishDate: '2025-06-06T20:41:34.271660Z'
publication_types:
- paper-conference
publication: '*EMRS Fall Meeting 2023*'
---
